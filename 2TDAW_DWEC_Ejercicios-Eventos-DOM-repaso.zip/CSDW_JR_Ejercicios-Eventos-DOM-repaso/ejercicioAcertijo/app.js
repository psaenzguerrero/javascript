window.addEventListener("load",
	()=>{
		setTimeout(()=>{
				
		},30000);
	})