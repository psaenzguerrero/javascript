window.addEventListener("load",
	()=>{
		
	})